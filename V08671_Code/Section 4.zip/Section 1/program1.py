print("Hello World")
name = "World"
print("Hello", name)
print("Hello " + name)
print("Hello", end=" ")
print(name)
print( "Hello {name}".format(name=name) )
